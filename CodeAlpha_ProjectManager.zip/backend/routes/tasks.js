// backend/routes/tasks.js
const express = require('express');
const Task = require('../models/Task');
const router = express.Router();

// create task
router.post('/', async (req, res) => {
  const t = new Task(req.body);
  await t.save();
  res.status(201).json(t);
});

// get tasks for project
router.get('/project/:projectId', async (req, res) => {
  const tasks = await Task.find({ project: req.params.projectId }).populate('assignee', 'name');
  res.json(tasks);
});

// update status
router.patch('/:id/status', async (req, res) => {
  const t = await Task.findById(req.params.id);
  if (!t) return res.status(404).json({ message: 'Not found' });
  t.status = req.body.status;
  await t.save();
  res.json(t);
});

// add comment
router.post('/:id/comment', async (req, res) => {
  const t = await Task.findById(req.params.id);
  t.comments.push({ user: req.body.userId, text: req.body.text });
  await t.save();
  res.json(t);
});

module.exports = router;
