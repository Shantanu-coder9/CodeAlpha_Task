// backend/routes/projects.js
const express = require('express');
const Project = require('../models/Project');
const router = express.Router();

// create
router.post('/', async (req, res) => {
  const p = new Project(req.body);
  await p.save();
  res.status(201).json(p);
});

// get all
router.get('/', async (req, res) => {
  const projects = await Project.find().populate('members', 'name email');
  res.json(projects);
});

// add member
router.post('/:id/members', async (req, res) => {
  const p = await Project.findById(req.params.id);
  if (!p) return res.status(404).json({ message: 'Project not found' });
  p.members.push(req.body.userId);
  await p.save();
  res.json(p);
});

module.exports = router;
