// backend/server.js
const express = require('express');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const cors = require('cors');
const path = require('path');

dotenv.config();
connectDB();

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth', require('./routes/auth'));
app.use('/api/posts', require('./routes/posts'));

// serve frontend
app.use(express.static(path.join(__dirname, '../frontend')));

const PORT = process.env.PORT || 5001;
app.listen(PORT, () => console.log(`Social backend on ${PORT}`));
