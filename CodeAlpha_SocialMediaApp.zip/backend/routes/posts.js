// backend/routes/posts.js
const express = require('express');
const Post = require('../models/Post');
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const router = express.Router();

const auth = (req, res, next) => {
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ message: 'No token' });
  const token = header.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secret');
    req.userId = decoded.id;
    next();
  } catch {
    res.status(401).json({ message: 'Invalid token' });
  }
};

// create post
router.post('/', auth, async (req, res) => {
  const post = new Post({ user: req.userId, text: req.body.text });
  await post.save();
  res.status(201).json(post);
});

// feed
router.get('/', async (req, res) => {
  const posts = await Post.find().populate('user', 'name').sort('-createdAt');
  res.json(posts);
});

// like/unlike
router.post('/:id/like', auth, async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) return res.status(404).json({ message: 'Not found' });
  const idx = post.likes.findIndex(x => x.equals(req.userId));
  if (idx === -1) post.likes.push(req.userId);
  else post.likes.splice(idx,1);
  await post.save();
  res.json(post);
});

// comment
router.post('/:id/comment', auth, async (req, res) => {
  const post = await Post.findById(req.params.id);
  post.comments.push({ user: req.userId, text: req.body.text });
  await post.save();
  res.json(post);
});

// follow/unfollow user
router.post('/user/:id/follow', auth, async (req, res) => {
  const target = await User.findById(req.params.id);
  const me = await User.findById(req.userId);
  if (!target) return res.status(404).json({ message: 'No user' });

  const idx = me.following.findIndex(x => x.equals(target._id));
  if (idx === -1) {
    me.following.push(target._id);
    target.followers.push(me._id);
  } else {
    me.following.splice(idx,1);
    target.followers = target.followers.filter(f => !f.equals(me._id));
  }
  await me.save(); await target.save();
  res.json({ me, target });
});

module.exports = router;
