// backend/routes/auth.js
const express = require('express');
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const router = express.Router();

router.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (await User.findOne({ email })) return res.status(400).json({ message: 'User exists' });
    const user = new User({ name, email, password });
    await user.save();
    res.status(201).json({ message: 'Registered' });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const u = await User.findOne({ email });
    if (!u || !(await u.matchPassword(password))) return res.status(401).json({ message: 'Invalid' });
    const token = jwt.sign({ id: u._id }, process.env.JWT_SECRET || 'secret', { expiresIn: '30d' });
    res.json({ token, user: { id: u._id, name: u.name, email: u.email } });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

module.exports = router;
